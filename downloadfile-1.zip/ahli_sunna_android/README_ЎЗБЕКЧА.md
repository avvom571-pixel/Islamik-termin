# Аҳли Сунна — Android илова лойиҳаси

Бу Android Studio учун тайёрланган лойиҳа. Сайт HTML файли илова ичига жойланган, шунинг учун асосий саҳифа интернетсиз ҳам очилиши керак. Қуръон/манбалар каби ташқи ҳаволалар учун интернет талаб қилиниши мумкин.

## APK йиғиш — Android Studio орқали
1. Компьютерга Android Studio ва Android SDK (API 35) ўрнатинг.
2. ZIP архивни чиқаринг.
3. Android Studio → **Open** → `AhliSunnaAndroid` папкасини танланг.
4. Gradle синхронлашуви тугагач, **Build → Build APK(s)** ни босинг.
5. APK одатда `app/build/outputs/apk/debug/app-debug.apk` манзилида чиқади.

## GitHub орқали APK йиғиш
1. Архивни чиқариб, файлларни GitHub репозиториясига `main` тармоғига юкланг.
2. Репозиторийда **Actions → Build Android APK → Run workflow** ни танланг (ёки `main` га push қилинг).
3. Тугашини кутинг; workflow натижасидаги `ahli-sunna-debug-apk` артефактини юклаб олинг. Ичида `app-debug.apk` бўлади.

## Муҳим
- Бу ZIP — Android лойиҳаси, APK файлининг ўзи эмас. Ушбу иш муҳитида Android SDK/Build Tools мавжуд эмаслиги сабабли APK ни бу ерда йиғиб, текшириш имкони бўлмади.
- `debug` APK тест ва шахсий ўрнатиш учун. Play Store учун алоҳида имзоланган `release` APK/AAB тайёрлаш керак.
